#ifndef PARSERH
#define PARSERH

/*Function Prototypes*/
unsigned int Parse(char* Input, char* Output[], unsigned int MaxWords);

#endif /* PARSERH */
